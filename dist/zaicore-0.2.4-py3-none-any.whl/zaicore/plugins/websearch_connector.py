def web_search(query):
    """Offline placeholder — connect to real API later."""
    print(f"[Plugin:websearch] Searching '{query}' ... (demo)")
    return f"No online result for '{query}' (plugin demo)."
