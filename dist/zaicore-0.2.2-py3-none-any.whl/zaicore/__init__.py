from .core import ZAICore

__version__ = "0.2.2"
__author__ = "Muhammad Zaidan"
