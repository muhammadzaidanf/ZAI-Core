# Init for ZAI Core package
from .core import ZAICore

__version__ = "0.1.0"
__author__ = "Muhammad Zaidan"
