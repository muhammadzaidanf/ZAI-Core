# Placeholder for plugin registry in future versions
