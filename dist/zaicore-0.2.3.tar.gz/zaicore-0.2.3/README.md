<div align="center">

# 🧠 ZAI Core  
### *v0.2.0 — Persistent Brain Update*

![PyPI](https://img.shields.io/pypi/v/zaicore?label=PyPI%20Version&style=for-the-badge&color=blue)
![Python](https://img.shields.io/badge/python-3.8%2B-green?style=for-the-badge)
![License](https://img.shields.io/github/license/muhammadzaidanf/ZAI-Core?style=for-the-badge)
![Made in Indonesia](https://img.shields.io/badge/Made%20in-Indonesia-red?style=for-the-badge)

</div>

---

## 🧩 Overview
**ZAI Core** is a modular Python-based AI framework built by **Muhammad Zaidan**.  
Version **v0.2.0** introduces **Persistent Memory**, allowing ZAI Core to remember what it learns — permanently.

> “Now your AI remembers — even after shutdown.”

---

## ⚙️ Features (v0.2.0)
- 🧠 **Persistent Brain** — Memory is saved in `zai_memory.json`  
- 💾 **Auto Save System** — Every `learn()` updates memory instantly  
- 🔍 **Recall Intelligence** — Retrieve old knowledge anytime  
- 🧩 **Forget & Wipe** — Erase single or all stored memories  
- 🧠 **CLI Mode** — Use ZAI Core directly from terminal  
- 🔧 **Configurable Path** — Custom memory file location  

---

## 🧱 Folder Structure
```text
./ZAI-Core/
│
├── ./zaicore/
│   ├── ./__init__.py
│   ├── ./__main__.py          # CLI Interface
│   ├── ./core.py              # Main AI Core Logic (Persistent Memory)
│   └── ./utils/
│       ├── ./__init__.py
│       └── ./data_handler.py  # Memory I/O Handler
│
├── ./docs/
│   └── ./architecture.md
│
├── ./setup.py
├── ./setup.cfg
├── ./LICENSE
└── ./README.md
```

---

## 💻 Quick Start

### Installation
```bash
pip install zaicore
```

### Example (Python)
```python
from zaicore import ZAICore

ai = ZAICore()

ai.learn("mission", "to build adaptive AI frameworks")
ai.learn("creator", "Muhammad Zaidan")

ai.recall("mission")
ai.recall("creator")
```

**Output:**
```
🧠 ZAI Core v0.2.0 initialized — Persistent Brain Online.
[Learning] Stored: mission -> to build adaptive AI frameworks
[Learning] Stored: creator -> Muhammad Zaidan
[Recall] mission: to build adaptive AI frameworks
[Recall] creator: Muhammad Zaidan
```

---

## 🧠 CLI Mode
> You can now talk to ZAI Core directly from your terminal.

```bash
python -m zaicore
```

**Example Interaction:**
```
🚀 Launching ZAI Core v0.2.0 — CLI Mode
🧠 ZAI Core v0.2.0 initialized — Persistent Brain Online.
Type 'exit' to quit.

🧠 > learn name = Zaidan
[Learning] Stored: name -> Zaidan

🧠 > recall name
[Recall] name: Zaidan

🧠 > forget name
[Forget] Key 'name' removed from memory.

🧠 > wipe
🧹 All memory wiped clean.

🧠 > exit
👋 Shutting down ZAI Core...
```

---

## ⚙️ Developer Notes
ZAI Core stores all learned data in a file called:
```
./zai_memory.json
```

To reset everything manually:
```bash
rm zai_memory.json
```

---

## 🧩 Development Roadmap

| Version | Feature | Status |
|----------|----------|--------|
| **v0.1.0** | Basic AI learn & recall system | ✅ Released |
| **v0.2.0** | Persistent Brain + CLI Mode | 🧠 Active |
| **v0.3.0** | Chat Interface + Plugin Loader | 🔜 Planned |

---

## 🧑‍💻 Author
**Muhammad Zaidan Faiz**  
💼 [LinkedIn](https://www.linkedin.com/in/mzaidanfaiz/)  
🌍 [GitHub](https://github.com/muhammadzaidanf)  
📧 [muhammadzaidanfaiz8@gmail.com](mailto:muhammadzaidanfaiz8@gmail.com)

---

## 📄 License
Released under the **MIT License** — free to learn, modify, and expand.

---

<div align="center">

⭐ *ZAI Core — The brain that never forgets.*  
<br>
💬 *“Don’t just build AI. Build something that learns with you.”*

</div>
